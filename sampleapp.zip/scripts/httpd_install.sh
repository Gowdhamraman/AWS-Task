#!/bin/bash
# Update package manager and install Nginx
yum update -y
yum  install nginx -y
