#!/bin/bash
# Start Nginx service and enable it to start on boot
systemctl start nginx
systemctl enable nginx
