#!/bin/bash
# Stop Nginx service
systemctl stop nginx
